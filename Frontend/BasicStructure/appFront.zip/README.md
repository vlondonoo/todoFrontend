# TodoAppFrontend-Angular

A Todo App made with Angular

## Running the project

1. Run the command `npm install`.
2. Run the command `npm run start`.
